package com.master.crm.dao;

import com.master.crm.model.User;

public interface UserDao extends BaseDaoInterface<User> {
}