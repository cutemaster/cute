drop database if exists honey;
create database honey CHARACTER SET utf8 COLLATE utf8_general_ci;
grant all privileges on honey.* to fish;